
-- Query 6 (clustered index)

DROP INDEX IF EXISTS unique1_index ON bprime;

CREATE UNIQUE INDEX IF NOT EXISTS unique2_index ON bprime(unique2);

EXPLAIN SELECT onemtup1.unique2 FROM onemtup1, bprime WHERE onemtup1.unique2 = bprime.unique2;

CREATE TEMPORARY TABLE temp SELECT onemtup1.unique2 FROM onemtup1, bprime WHERE onemtup1.unique2 = bprime.unique2;

