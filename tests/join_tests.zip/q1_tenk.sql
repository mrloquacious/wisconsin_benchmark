
-- Query 1 (no index) 10000

-- Drop any auto-created indices:
DROP INDEX IF EXISTS `PRIMARY` ON onemtup1;
DROP INDEX IF EXISTS `PRIMARY` ON onemtup2;

-- Get details on how the query will be processed:
EXPLAIN SELECT onemtup1.unique2 FROM onemtup1, onemtup2 WHERE onemtup1.unique2 = onemtup2.unique1 AND onemtup2.unique2 < 10000;

-- Run the query:
CREATE TEMPORARY TABLE temp SELECT onemtup1.unique2 FROM onemtup1, onemtup2  WHERE onemtup1.unique2 = onemtup2.unique2 AND onemtup2.unique2 < 10000;

