-- Query 3 (clustered index)

-- Drop exisiting index:
DROP INDEX IF EXISTS unique1_index ON onemtup1;

-- Create a clustered index:
CREATE UNIQUE INDEX IF NOT EXISTS unique2_index ON onemtup1(unique2);

-- Get details on how the query will be processed:
EXPLAIN SELECT onemtup1.unique2 FROM onemtup1, onemtup2  WHERE onemtup1.unique2 = onemtup2.unique2 AND onemtup2.unique2 < 100000;

-- Run the query:
CREATE TEMPORARY TABLE temp SELECT onemtup2.unique2 FROM onemtup1, onemtup2 WHERE onemtup1.unique2 = onemtup2.unique2 AND onemtup2.unique2 < 100000;

