
-- Create bprime:

CREATE TABLE bprime LIKE onemtup1;
INSERT INTO bprime SELECT * FROM onemtup1 WHERE onemtup1.unique2 < 100000;
