
-- Query 4 (no index)

DROP INDEX IF EXISTS unique2_index ON onemtup1;

EXPLAIN SELECT onemtup1.unique2 FROM onemtup1, bprime WHERE onemtup1.unique2 = bprime.unique2;

--CREATE TEMPORARY TABLE temp SELECT onemtup1.unique2 FROM onemtup1, bprime WHERE onemtup1.unique2 = bprime.unique2;

