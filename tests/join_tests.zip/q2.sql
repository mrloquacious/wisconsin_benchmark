
--Query 2 (unclustered index)

-- Create an unclustered index:
CREATE UNIQUE INDEX IF NOT EXISTS unique1_index ON onemtup1(unique1);

-- Get details on how the query will be processed:
EXPLAIN SELECT onemtup1.unique1 FROM onemtup1, onemtup2 WHERE onemtup1.unique1 = onemtup2.unique1 AND onemtup1.unique1 < 100000;

-- Run the query:
CREATE TEMPORARY TABLE temp SELECT onemtup1.unique1 FROM onemtup1, onemtup2 WHERE onemtup1.unique1 = onemtup2.unique1 AND onemtup1.unique1 < 100000;

