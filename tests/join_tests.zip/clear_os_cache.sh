
# Before
free -m

# Sync and clear the cache before running each experiment:
# This didn't work due to permissions issues:
# sync; sudo echo 3 > /proc/sys/vm/drop_caches

# Found this on Stack Exchange and it seems to work:
sync; sudo sh -c "/usr/bin/echo 3 > /proc/sys/vm/drop_caches"

# After
free -m

