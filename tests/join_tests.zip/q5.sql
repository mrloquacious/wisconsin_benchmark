
-- Query 5 (unclustered index)

CREATE UNIQUE INDEX IF NOT EXISTS unique1_index ON bprime(unique1);

EXPLAIN SELECT onemtup1.unique1 FROM onemtup1, bprime WHERE onemtup1.unique1 = bprime.unique1;

CREATE TEMPORARY TABLE temp SELECT onemtup1.unique1 FROM onemtup1, bprime WHERE onemtup1.unique1 = bprime.unique1;

